import React from 'react'

function ScreenCalibration() {
    return <div className="screen-calibration-wrapper"><div className="calibration-box"></div></div>
}

export default ScreenCalibration
